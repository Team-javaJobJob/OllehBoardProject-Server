package com.example.ollethboardproject.domain;

import lombok.Getter;

@Getter
public enum Gender {
    MALE,
    FEMALE

}
