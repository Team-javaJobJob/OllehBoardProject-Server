package com.example.ollethboardproject.controller.request.reply;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ReplyUpdateRequest {
    private String content;
}