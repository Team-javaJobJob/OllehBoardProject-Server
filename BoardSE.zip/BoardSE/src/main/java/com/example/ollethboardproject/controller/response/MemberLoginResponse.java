package com.example.ollethboardproject.controller.response;

import lombok.AllArgsConstructor;
import lombok.Getter;

@AllArgsConstructor
@Getter
public class MemberLoginResponse {
    private String accessToken;
    private String refreshToken;
}
