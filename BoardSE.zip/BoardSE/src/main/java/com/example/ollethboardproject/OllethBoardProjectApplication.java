package com.example.ollethboardproject;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OllethBoardProjectApplication {

    public static void main(String[] args) {
        SpringApplication.run(OllethBoardProjectApplication.class, args);
    }

}
