package com.example.ollethboardproject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OllethBoardProjectApplicationTests {

    @Test
    void contextLoads() {
    }

}
